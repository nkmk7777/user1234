from datetime import datetime, timedelta
from typing import Optional

from sqlalchemy import select, update
from sqlalchemy.dialects.mysql import insert
from sqlalchemy.exc import NoResultFound

from infrastructure.database.models import User
from infrastructure.database.repo.base import BaseRepo


class UserRepo(BaseRepo):
    async def create_user(
        self,
        user_id: int,
        full_name: str,
        username: Optional[str] = None,
    ):
        """
        Creates or updates a new user in the database and returns the user object.
        :param user_id: The user's ID.
        :param full_name: The user's full name.
        :param language: The user's language.
        :param username: The user's username. It's an optional parameter.
        :return: User object, None if there was an error while making a transaction.
        """

        insert_stmt = insert(User).values(
            user_id=user_id,
            username=username,
            full_name=full_name,
        )
        print(insert_stmt)
        await self.session.execute(insert_stmt)
        await self.session.commit()

    async def get_user(self, user_id):
        stmt = select(User).where(User.user_id == user_id)
        result = await self.session.execute(stmt)
        try:
            return result.scalar_one()
        except NoResultFound:
            return None

    async def get_user_by_username(self, username):
        stmt = select(User).where(User.username == username)
        result = await self.session.execute(stmt)
        try:
            return result.scalar_one()
        except NoResultFound:
            return None

    async def update_user(self, user_id, **kwargs):
        stmt = update(User).where(User.user_id == user_id).values(**kwargs)
        await self.session.execute(stmt)
        await self.session.commit()

    async def get_active_users(self):
        twenty_four_hours_ago = datetime.now() - timedelta(hours=24)
        stmt = select(User).filter(User.last_activity >= twenty_four_hours_ago)
        result = await self.session.execute(stmt)
        return result.scalars().all()

    
    async def get_all_users(self):
        stmt = select(User)
        result = await self.session.execute(stmt)
        return result.scalars().all()